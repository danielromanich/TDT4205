#include <vslc.h>

static const char *record[6] = {
    "%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"
};


void
generate_program ( void )
{
}
